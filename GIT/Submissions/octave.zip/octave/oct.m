data = dlmread ('train.csv',',',0,0);
if (data(1,1)==0)
	rawxtrain = data(2:end , 1 );
	y_train = data(2:end , 2);
else
	rawxtrain = data(: , 1 );
	y_train = data(: , 2);
end

len = rows(rawxtrain);

one = ones(len,1);
x_train = [one,rawxtrain];
w = rand(2,1);
xdata1 = x_train * w;

figure(1)

scatter(rawxtrain, y_train);hold on;
plot(rawxtrain, xdata1);
#print -dpdf "fig1.pdf";


w_direct = inv((x_train)' * (x_train)) * x_train' * y_train;

figure(2)

scatter(rawxtrain, y_train);hold on;
plot(rawxtrain, x_train * w_direct);

#print -dpdf "fig2.pdf";


figure(3)
for i = 1:2
    for j = 1:len
        eta = 0.00000001;
        x = rawxtrain(j);
        y = y_train(j);
        x_bar = x_train(j,:)';
        w = w - (eta*((w' * x_bar)-y)*x_bar);
        if rem(j,100) == 0
            plot(rawxtrain, x_train * w);
            hold on;
        endif
    end
end
w
plot(rawxtrain, y_train);
#print -dpdf "fig3.pdf";

figure(4)
scatter(rawxtrain, y_train);hold on;
plot(rawxtrain, x_train * w);hold on;

testdata = dlmread ('test.csv',',',0,0);
if (testdata(1,1)==0)
	rawxt = testdata(2:end , 1 );
	yt = testdata(2:end , 2);
else
	rawxt = testdata(: , 1 );
	yt = testdata(: , 2);
end


lent = rows(rawxt);
onet = ones(lent,1);
xt = [onet,rawxt];

ypred1 = xt * w;
ypred2 = xt * w_direct;
sum1 = 0.0;
sum2 = 0.0;
for i = 1:lent
    sum1 = sum1 + (ypred1(i)-yt(i))^2;
    sum2 = sum2 + (ypred2(i)-yt(i))^2;
end
rms1 = sqrt(sum1/lent);
rms2 = sqrt(sum2/lent);
rms1
rms2
