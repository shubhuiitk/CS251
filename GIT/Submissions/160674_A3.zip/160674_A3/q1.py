#!/usr/bin/python

import sys
flag = 0;

y = sys.argv[1].split("-")
if(len(y)>2):
	print "Invalid input"
	sys.exit()
if(len(y) == 1):
	u = 0
else:
	u = 1

x = y[u].split(".")
if (len(x) == 1):
	flag = 1
elif (len(x) > 2):
	print "Invalid input"
	sys.exit()

dict = {}
j = 10
num = 0
from string import ascii_uppercase
for i in "0123456789":
	dict[i] = num
	num += 1
for i in ascii_uppercase:
	dict[i] = j
	j += 1

for i in x[0]:
	if (i == '0'):
		x[0] = x[0][1:]
	else:
	 break

sum1 = 0
sum2 = 0
pos1 = len(x[0]) - 1
index1 = 0
index2 = -1
if not sys.argv[2].isdigit():
	print "Invalid input"
	sys.exit()
b = float(sys.argv[2])
i = 0

while (pos1 >= 0):
	if x[0][pos1:pos1+1] in dict:
		if(dict[x[0][pos1:pos1+1]] >= b):
			print "Invalid input"
			sys.exit()
		sum1 += pow( b, index1) * dict[x[0][pos1:pos1+1]]
		pos1 = pos1 - 1
		index1 += 1
	else:
	  print "Invalid input"
	  sys.exit()

if (flag == 0):
	index2 = -1
	i = 0
	pos2 = len(x[1]) - 1
	while (i <= pos2):
		if x[1][i:i+1] in dict:
			if(dict[x[1][i:i+1]] >= b):
				print "Invalid input"
				sys.exit()
			sum2 += pow( b, index2) * dict[x[1][i:i+1]]
			i += 1
			index2 = index2 - 1
		else:
		  print "Invalid input"
		  sys.exit()
if (sum1+sum2) > 999999999 or b < 2 or b > 36:
	print "Invalid input"
	sys.exit()
if (len(y) == 2):
	print "-{}".format(sum1+sum2)
else:
	print sum1+sum2
