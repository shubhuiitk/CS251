#!/bin/bash
index=0
arr=( 0 0 )
index=$((0))
for file in $(find $1 -type f -name "*.c"); do
	parameter=$(awk -f new.awk $file)
	for i in $parameter; do
		arr[$index]=$((arr[$index]+$i))
		((index++))
		done
		index=$((0))
	done
echo Number of comments = ${arr[0]}
echo Number of strings = ${arr[1]}
